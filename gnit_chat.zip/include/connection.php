<?php 
$con = mysqli_connect("sql310.byetcluster.com","epiz_32921449","5ERvyeyvwUEfZRY","epiz_32921449_mychat")
// $con = mysqli_connect("localhost","root","","mychat")
or die("data-connection error");

?>