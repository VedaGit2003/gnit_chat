<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/credit.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
  <body>
    <a href="index.php" class="gohome">HOME</a>
    <div class="credits">
      <div class="inner">
        <h1>Credits</h1>
        
        <div class="border"></div>

        <div class="row">
          <div class="col">
            <div class="credit">
              <img src="sources/sourav.png" alt="">
              <div class="name">Sourav Nath</div>
         
              <p>
                Name:Sourav Nath<br/>
                Class Roll:155<br />
                Stream:Computer Science and Engineering<br />
                Academic Year:second<br />
        
              </p>
            </div>
          </div>

          <div class="col">
            <div class="credit">
              <img src="sources/veda.jpeg" alt="">
              <div class="name">Veda paul chowdhury</div>
          
              <p>
                Name:Veda Paul Chowdhury<br />
                Class Roll:188<br />
                Stream:Computer Science and Engineering<br />
                Academic Year:second<br />
              </p>
            </div>
          </div>

          <div class="col">
            <div class="credit">
              <img src="sources/shibom.jpeg" alt="">
              <div class="name">Shibam Chakraborty</div>
            
              <p>
                Name:Shibam Chakraborty<br />
                Class Roll:137<br />
                Stream:Computer Science and Engineering<br />
                Academic Year:second<br />
              </p>
            </div>
          </div>
           
            <div class="col">
              <div class="credit">
                <img src="sources/shradha.jpeg" alt="">
                <div class="name">Shradha Biswas</div>
            
            
                <p>
                  Name:Shradha Biswas<br />
                  Class Roll:139<br />
                  Stream:Computer Science and Engineering<br />
                  Academic Year:second<br />
                </p>
              </div>
            </div>

              <div class="col">
                <div class="credit">
                  <img src="sources/sree.jpeg" alt="">
                  <div class="name">Sreeranjana Ghosh</div>

              
                  <p>
                      Name:Sreeranjana Ghosh<br />
                      Class Roll:158<br />
                      Stream:Computer Science and Engineering<br />
                      Academic Year:second<br />
                  </p>
                </div>
              </div>
        </div>
      </div>
    </div>

  </body>
</html>
